package com.example.sample3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sample3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
