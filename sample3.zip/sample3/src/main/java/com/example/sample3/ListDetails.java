package com.example.sample3;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class ListDetails {
	
	@Id
	private int Cid;
	private String Cname;
	private String Cdesc;
	@OneToMany(mappedBy= "details")
	private List<Course> course;
	public int getCid() {
		return Cid;
	}
	public void setCid(int cid) {
		Cid = cid;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public String getCdesc() {
		return Cdesc;
	}
	public void setCdesc(String cdesc) {
		Cdesc = cdesc;
	}
	@Override
	public String toString() {
		return "ListDetails [Cid=" + Cid + ", Cname=" + Cname + ", Cdesc=" + Cdesc + "]";
	}

	
}
