package com.example.sample3;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

public class Sample3Controller {
	
	public Sample3Service sample3service;
	
	@RequestMapping("/{category}/{course}")
	public void categories(@PathVariable("category") String category, @PathVariable("course") String Course) {
		 sample3service.getCategory(category, Course);
	}
	
}
