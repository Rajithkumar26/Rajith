package com.example.sample3;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Course {
	@Id
	private int courseid;
	private String coursename;
	private int courseduration;
	private int coursemiles;
	@ManyToOne
	private ListDetails details;
	public int getCourseid() {
		return courseid;
	}
	public void setCourseid(int courseid) {
		this.courseid = courseid;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public int getCourseduration() {
		return courseduration;
	}
	public void setCourseduration(int courseduration) {
		this.courseduration = courseduration;
	}
	public int getCoursemiles() {
		return coursemiles;
	}
	public void setCoursemiles(int coursemiles) {
		this.coursemiles = coursemiles;
	}
	@Override
	public String toString() {
		return "Course [courseid=" + courseid + ", coursename=" + coursename + ", courseduration=" + courseduration
				+ ", coursemiles=" + coursemiles + "]";
	}
	
	

}
