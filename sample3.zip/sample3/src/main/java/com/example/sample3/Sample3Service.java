 package com.example.sample3;

public class Sample3Service {

	private CrudRepo crudrepo;
	
	public String getCategory(String cat, String cour) {
		// TODO Auto-generated method stub
		ListDetails details= (ListDetails) crudrepo.findById(cat, cour);
		
		return 0 ;
		
	}

}
