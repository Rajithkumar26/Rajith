package com.example.sample2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sample2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
