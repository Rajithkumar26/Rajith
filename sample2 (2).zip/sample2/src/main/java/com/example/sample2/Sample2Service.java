package com.example.sample2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Sample2Service {

	public List<Employee> emplist= new ArrayList<>(Arrays.asList(new Employee(132, "latha", 4, "Ahmadabad"), new Employee(134, "sunidha", 4, "delhi"), new Employee(131, "Rohan", 5, "chennai"), new Employee(133, "Rakesh", 5, "Hyderabad")));
	
	public List<Employee> getsorting(){
		int c;
		Collections.sort(List<Employee>emplist, Comparator<Employee>c);
		return emplist;
	}
}
 